// 项目界面选择更多菜单后的底部管理菜单组件
Component({
  /**
   * 组件的属性列表
   */
  properties: {

  },

  /**
   * 组件的初始数据
   */
  data: {

  },

  /**
   * 组件的方法列表
   */
  methods: {
    move: function () {
    },
    share: function () {
    },
    like: function () {
    },
    copy: function () {
    },
  }
})
